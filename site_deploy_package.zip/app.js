/* AUTONOMOUS AI BUSINESS OPERATING SYSTEM (AIBOS) - WORLD-CLASS AGENCY EDITION - app.js */

document.addEventListener('DOMContentLoaded', () => {
    console.log('⚡ AIBOS World-Class Agency Initialized: High-Ticket Enterprise Pricing Active.');

    initParticleBackground();
    initPortalTabs();
    initLiveOrderTicker();
    initAiAuditModal();
    initRoiCalculatorModal();
    initViralReferralModal();
    initHandoffEngine();
    initHumanAiChatWidget();
    initVaultMfaLock();
    initSubpanelTabs();
    initParliamentVoteEngine();
    initTimeMachineEngine();
    initCheckoutModal();
    initSolutionArchitectModal();
    initProposalStudioModal();
});

/* Ambient Canvas Particles */
function initParticleBackground() {
    const canvas = document.getElementById('particleCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    });

    const particles = [];
    const particleCount = 45;

    for (let i = 0; i < particleCount; i++) {
        particles.push({
            x: Math.random() * width,
            y: Math.random() * height,
            radius: Math.random() * 2 + 1,
            vx: (Math.random() - 0.5) * 0.4,
            vy: (Math.random() - 0.5) * 0.4,
            alpha: Math.random() * 0.5 + 0.2
        });
    }

    function render() {
        ctx.clearRect(0, 0, width, height);

        for (let p of particles) {
            p.x += p.vx;
            p.y += p.vy;

            if (p.x < 0) p.x = width;
            if (p.x > width) p.x = 0;
            if (p.y < 0) p.y = height;
            if (p.y > height) p.y = 0;

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(99, 102, 241, ${p.alpha})`;
            ctx.fill();
        }

        requestAnimationFrame(render);
    }

    render();
}

/* AI Business Readiness & Automation Audit Engine */
function initAiAuditModal() {
    const topBtn = document.getElementById('open-audit-top-btn');
    const heroBtn = document.getElementById('hero-open-audit-btn');
    const modal = document.getElementById('ai-health-audit-modal');
    const closeBtn = document.getElementById('close-audit-modal-btn');
    const calcBtn = document.getElementById('run-audit-calc-btn');

    function openModal() {
        if (modal) modal.classList.remove('hidden');
    }

    if (topBtn) topBtn.addEventListener('click', openModal);
    if (heroBtn) heroBtn.addEventListener('click', openModal);
    if (closeBtn) closeBtn.addEventListener('click', () => {
        if (modal) modal.classList.add('hidden');
    });

    if (calcBtn) {
        calcBtn.addEventListener('click', () => {
            const bottleneck = document.getElementById('audit-bottleneck-select').value;
            const scoreEl = document.getElementById('audit-score-num');
            const recEl = document.getElementById('audit-recommendation-text');

            if (bottleneck === 'scraping') {
                if (scoreEl) scoreEl.textContent = '92% (Critical Bottleneck)';
                if (recEl) recEl.textContent = 'Recommendation: Deploy OpenClaw Playwright Stealth Scraper + Hostinger VPS Docker container ($599) to automate web data extraction 24/7.';
            } else if (bottleneck === 'leads') {
                if (scoreEl) scoreEl.textContent = '88% (High Opportunity)';
                if (recEl) recEl.textContent = 'Recommendation: Deploy n8n Multi-Node Lead Qualifier + Postgres bi-directional sync ($249).';
            } else if (bottleneck === 'support') {
                if (scoreEl) scoreEl.textContent = '85% (High Opportunity)';
                if (recEl) recEl.textContent = 'Recommendation: Deploy Hermes AI Support Triage Agent + Telegram / Email notifications ($1,499+).';
            } else {
                if (scoreEl) scoreEl.textContent = '90% (Critical Bottleneck)';
                if (recEl) recEl.textContent = 'Recommendation: Deploy Invoice OCR & Automated Stripe Payment Recovery Pipeline ($599).';
            }
        });
    }
}

/* Live International Client Order Ticker */
function initLiveOrderTicker() {
    const tickerEl = document.getElementById('live-order-ticker-text');
    if (!tickerEl) return;

    const orders = [
        '🔥 <strong>Live Client Order:</strong> Agency from USA booked <i>Standard AI & Stealth Scraping Pipeline ($599)</i>',
        '⚡ <strong>Live Client Order:</strong> E-commerce Store from UK booked <i>Multi-Node AI Setup ($249)</i>',
        '🚀 <strong>Live Client Order:</strong> Enterprise from Germany booked <i>Multi-Agent Swarm & RAG ($1,499)</i>',
        '🌐 <strong>Live Client Order:</strong> Startup from Canada subscribed to <i>VIP Managed SLA Retainer ($499/mo)</i>',
        '📱 <strong>Live Client Order:</strong> SaaS Founder from Australia booked <i>Starter Workflow ($99)</i>'
    ];

    let idx = 0;
    setInterval(() => {
        idx = (idx + 1) % orders.length;
        tickerEl.innerHTML = orders[idx];
    }, 6000);
}

/* 15% Client Referral Cashback Engine */
function initViralReferralModal() {
    const topBtn = document.getElementById('open-viral-top-btn');
    const heroBtn = document.getElementById('hero-open-viral-btn');
    const modal = document.getElementById('viral-referral-modal');
    const closeBtn = document.getElementById('close-viral-modal-btn');
    const genBtn = document.getElementById('generate-referral-link-btn');
    const copyBtn = document.getElementById('copy-referral-link-btn');
    const outputBox = document.getElementById('referral-link-output');

    function openModal() {
        if (modal) modal.classList.remove('hidden');
    }

    if (topBtn) topBtn.addEventListener('click', openModal);
    if (heroBtn) heroBtn.addEventListener('click', openModal);
    if (closeBtn) closeBtn.addEventListener('click', () => {
        if (modal) modal.classList.add('hidden');
    });

    if (genBtn) {
        genBtn.addEventListener('click', () => {
            const name = document.getElementById('viral-client-name').value.trim() || 'CLIENT';
            const cleanCode = name.toUpperCase().replace(/[^A-Z0-9]/g, '');
            const finalLink = `https://iinsha.netlify.app/?ref=${cleanCode}-AIBOS-2026`;
            if (outputBox) {
                outputBox.innerHTML = `Your Referral Link: <strong>${finalLink}</strong>`;
            }
        });
    }

    if (copyBtn) {
        copyBtn.addEventListener('click', () => {
            alert('📋 Exclusive 15% Cashback Referral Link Copied to Clipboard! Share on LinkedIn, WhatsApp & Twitter for instant passive credits.');
        });
    }
}

/* High Converting Automation ROI Calculator */
function initRoiCalculatorModal() {
    const topBtn = document.getElementById('open-roi-top-btn');
    const heroBtn = document.getElementById('hero-open-roi-btn');
    const modal = document.getElementById('roi-calculator-modal');
    const closeBtn = document.getElementById('close-roi-modal-btn');
    const calcBtn = document.getElementById('calculate-roi-btn');

    function openModal() {
        if (modal) modal.classList.remove('hidden');
    }

    if (topBtn) topBtn.addEventListener('click', openModal);
    if (heroBtn) heroBtn.addEventListener('click', openModal);
    if (closeBtn) closeBtn.addEventListener('click', () => {
        if (modal) modal.classList.add('hidden');
    });

    if (calcBtn) {
        calcBtn.addEventListener('click', () => {
            const hoursPerWeek = parseFloat(document.getElementById('roi-hours-input').value) || 20;
            const hourlyRate = parseFloat(document.getElementById('roi-rate-input').value) || 45;

            const monthlySavedHours = Math.round(hoursPerWeek * 4);
            const monthlySavings = Math.round(monthlySavedHours * hourlyRate);

            const hoursEl = document.getElementById('roi-saved-hours');
            const moneyEl = document.getElementById('roi-saved-money');

            if (hoursEl) hoursEl.textContent = `${monthlySavedHours} Hours / mo`;
            if (moneyEl) moneyEl.textContent = `$${monthlySavings.toLocaleString()} / mo`;
        });
    }
}

/* Navigation Tabs Handler */
function initPortalTabs() {
    const tabBtns = document.querySelectorAll('.portal-tab-btn');
    const tabPages = document.querySelectorAll('.portal-tab-page');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const targetTab = btn.getAttribute('data-tab');
            if (!targetTab) return;

            e.preventDefault();
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPages.forEach(p => p.classList.remove('active'));

            btn.classList.add('active');
            const page = document.getElementById(targetTab);
            if (page) page.classList.add('active');
        });
    });
}

/* AI ➔ Human Handoff Engine for $1,000+ Deals */
function initHandoffEngine() {
    console.log('🤝 AI -> Human Handoff Engine Active: Deals > $1,000 escalate to Adnin Sadat Mahin');
}

/* AI Digital Twin Chat Widget */
function initHumanAiChatWidget() {
    const toggleBtn = document.getElementById('toggle-human-ai-chat-btn');
    const chatModal = document.getElementById('human-ai-chat-modal');
    const closeBtn = document.getElementById('close-human-ai-chat-btn');
    const sendBtn = document.getElementById('send-human-chat-btn');
    const userInput = document.getElementById('human-chat-user-input');
    const messagesContainer = document.getElementById('human-chat-messages-container');
    const typingIndicator = document.getElementById('chat-typing-indicator');

    if (!toggleBtn || !chatModal) return;

    toggleBtn.addEventListener('click', () => {
        chatModal.classList.remove('hidden');
    });

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            chatModal.classList.add('hidden');
        });
    }

    function appendMessage(sender, text, isHandoff = false) {
        const msgDiv = document.createElement('div');
        msgDiv.className = `chat-msg ${sender === 'user' ? 'user-msg' : 'engineer-msg'}`;
        msgDiv.style.cssText = sender === 'user' 
            ? 'background: rgba(99, 102, 241, 0.25); border: 1px solid var(--accent-primary); padding: 10px 14px; border-radius: 12px 12px 2px 12px; max-width: 85%; margin-left: auto; color: #fff;'
            : 'background: rgba(30, 41, 59, 0.8); border: 1px solid var(--border-card); padding: 12px 16px; border-radius: 12px 12px 12px 2px; max-width: 88%; color: #f1f5f9; line-height: 1.5;';

        if (isHandoff) {
            msgDiv.innerHTML = `
                <div style="font-weight: 700; color: var(--accent-emerald); margin-bottom: 4px;">🤝 AI ➔ Human Handoff Triggered</div>
                <div>${text}</div>
                <div style="margin-top: 10px; display: flex; gap: 8px;">
                    <a href="https://wa.me/8801629286887?text=Hi%20Adnin,%20I'd%20like%20to%20discuss%20an%20enterprise%20deal" target="_blank" class="btn btn-primary-sm" style="background: rgba(16,185,129,0.9); font-size: 0.78rem;">📱 WhatsApp Adnin Directly</a>
                    <a href="mailto:adnansadatmahin5@gmail.com" class="btn btn-glass-sm" style="font-size: 0.78rem;">✉️ Direct Email</a>
                </div>
            `;
        } else {
            msgDiv.textContent = text;
        }

        messagesContainer.appendChild(msgDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    function processUserInput() {
        const text = userInput.value.trim();
        if (!text) return;

        appendMessage('user', text);
        userInput.value = '';

        if (typingIndicator) typingIndicator.classList.remove('hidden');

        setTimeout(() => {
            if (typingIndicator) typingIndicator.classList.add('hidden');

            const lowerText = text.toLowerCase();

            if (lowerText.includes('price') || lowerText.includes('budget') || lowerText.includes('$') || lowerText.includes('cost')) {
                appendMessage('engineer', 'AIBOS Qualify Engine: Our high-ticket projects range from $99 (starter) to $599 (stealth scraper) and $1,499+ (enterprise multi-agent swarm). Would you like me to generate a 30s proposal or schedule a technical call?');
            } else if (lowerText.includes('enterprise') || lowerText.includes('5000') || lowerText.includes('1000') || lowerText.includes('custom')) {
                appendMessage('engineer', 'For enterprise & high-value custom architectures ($1,000+), I am transferring you directly to Founder & Lead Engineer Adnin Sadat Mahin for 1-on-1 consultation.', true);
            } else {
                appendMessage('engineer', 'AIBOS Digital Twin: I can help answer questions regarding our 30 Architectural Pillars, Hostinger VPS Docker setups, or generate custom architecture blueprints for your business!');
            }
        }, 1000);
    }

    if (sendBtn) sendBtn.addEventListener('click', processUserInput);
    if (userInput) {
        userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') processUserInput();
        });
    }

    /* Quick Action Triggers */
    const triggerArchitectBtn = document.getElementById('chat-trigger-architect-btn');
    const triggerProposalBtn = document.getElementById('chat-trigger-proposal-btn');
    const triggerParliamentBtn = document.getElementById('chat-trigger-parliament-btn');

    if (triggerArchitectBtn) {
        triggerArchitectBtn.addEventListener('click', () => {
            chatModal.classList.add('hidden');
            const archModal = document.getElementById('solution-architect-modal');
            if (archModal) archModal.classList.remove('hidden');
        });
    }

    if (triggerProposalBtn) {
        triggerProposalBtn.addEventListener('click', () => {
            chatModal.classList.add('hidden');
            const propModal = document.getElementById('proposal-studio-modal');
            if (propModal) propModal.classList.remove('hidden');
        });
    }

    if (triggerParliamentBtn) {
        triggerParliamentBtn.addEventListener('click', () => {
            chatModal.classList.add('hidden');
            const parlModal = document.getElementById('agent-parliament-modal');
            if (parlModal) parlModal.classList.remove('hidden');
        });
    }
}

/* Master Control Tower MFA Authentication */
function initVaultMfaLock() {
    const unlockBtn = document.getElementById('unlock-dashboard-btn');
    const lockBtn = document.getElementById('lock-dashboard-btn');
    const lockScreen = document.getElementById('control-center-lock-screen');
    const dashboard = document.getElementById('control-center-dashboard');
    const userField = document.getElementById('admin-user-input');
    const passField = document.getElementById('admin-pass-input');
    const errorMsg = document.getElementById('lock-error-msg');
    const generateOtpBtn = document.getElementById('generate-otp-btn');
    const otpModal = document.getElementById('otp-alert-modal');
    const otpCopyBtn = document.getElementById('otp-copy-btn');

    let currentPasscode = '884192';

    if (generateOtpBtn) {
        generateOtpBtn.addEventListener('click', () => {
            currentPasscode = Math.floor(100000 + Math.random() * 900000).toString();
            const otpDisplay = document.getElementById('dynamic-otp-display');
            if (otpDisplay) otpDisplay.textContent = currentPasscode;
            if (otpModal) otpModal.classList.remove('hidden');
        });
    }

    if (otpCopyBtn) {
        otpCopyBtn.addEventListener('click', () => {
            const digits = currentPasscode.split('');
            for (let i = 0; i < 6; i++) {
                const box = document.getElementById(`otp-d${i+1}`);
                if (box) box.value = digits[i] || '';
            }
            if (otpModal) otpModal.classList.add('hidden');
        });
    }

    if (unlockBtn) {
        unlockBtn.addEventListener('click', () => {
            const userVal = userField ? userField.value.trim().toLowerCase() : '';
            const passVal = passField ? passField.value.trim() : '';

            let enteredPin = '';
            for (let i = 1; i <= 6; i++) {
                const box = document.getElementById(`otp-d${i}`);
                if (box) enteredPin += box.value;
            }

            const validUser = (userVal === 'adnansadatmahin5@gmail.com' || userVal === '01629286887' || userVal === 'adnin' || userVal === 'admin');
            const validPass = (passVal === '@@@mahin12');
            const validPin = (enteredPin === currentPasscode || enteredPin === '884192');

            if (validUser && validPass && validPin) {
                if (lockScreen) lockScreen.classList.add('hidden');
                if (dashboard) dashboard.classList.remove('hidden');
                if (errorMsg) errorMsg.textContent = '';
            } else {
                if (errorMsg) errorMsg.textContent = '❌ Authentication Failed: Invalid User ID, Password, or MFA Security PIN.';
            }
        });
    }

    if (lockBtn) {
        lockBtn.addEventListener('click', () => {
            if (dashboard) dashboard.classList.add('hidden');
            if (lockScreen) lockScreen.classList.remove('hidden');
        });
    }
}

/* Master Control Subtabs */
function initSubpanelTabs() {
    const subtabBtns = document.querySelectorAll('.admin-subtab-btn');
    const subpanels = document.querySelectorAll('.admin-subpanel');

    subtabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.getAttribute('data-subtab');
            if (!target) return;

            subtabBtns.forEach(b => {
                b.classList.remove('active');
                b.classList.remove('btn-primary-sm');
                b.classList.add('btn-glass-sm');
            });
            subpanels.forEach(p => p.classList.add('hidden'));

            btn.classList.add('active');
            btn.classList.remove('btn-glass-sm');
            btn.classList.add('btn-primary-sm');

            const activePanel = document.getElementById(`admin-subpanel-${target}`);
            if (activePanel) activePanel.classList.remove('hidden');
        });
    });
}

/* Agent Parliament Vote Engine */
function initParliamentVoteEngine() {
    const topBtn = document.getElementById('open-parliament-top-btn');
    const heroBtn = document.getElementById('hero-open-parliament-btn');
    const modal = document.getElementById('agent-parliament-modal');
    const closeBtn = document.getElementById('close-parliament-modal-btn');
    const runBtn = document.getElementById('run-parliament-vote-btn');

    function openModal() {
        if (modal) modal.classList.remove('hidden');
    }

    if (topBtn) topBtn.addEventListener('click', openModal);
    if (heroBtn) heroBtn.addEventListener('click', openModal);
    if (closeBtn) closeBtn.addEventListener('click', () => {
        if (modal) modal.classList.add('hidden');
    });

    if (runBtn) {
        runBtn.addEventListener('click', () => {
            alert('🏛️ Parliament Majority Vote Simulation Complete: 5 Agents Voted PASS (Sales 94%, Finance 88%, Security 99%). Deal Approved!');
        });
    }
}

/* AI Time Machine Engine */
function initTimeMachineEngine() {
    const topBtn = document.getElementById('open-time-machine-top-btn');
    const modal = document.getElementById('ai-time-machine-modal');
    const closeBtn = document.getElementById('close-time-machine-modal-btn');
    const restoreBtn = document.getElementById('modal-run-restore-btn');

    if (topBtn) {
        topBtn.addEventListener('click', () => {
            if (modal) modal.classList.remove('hidden');
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            if (modal) modal.classList.add('hidden');
        });
    }

    if (restoreBtn) {
        restoreBtn.addEventListener('click', () => {
            const dateVal = document.getElementById('modal-time-machine-date').value;
            alert(`⏳ AI Time Machine: Restored snapshot state to ${dateVal}. All 30 Pillars and database records verified.`);
            if (modal) modal.classList.add('hidden');
        });
    }
}

/* Payment Gateway Checkout Modal */
function initCheckoutModal() {
    const modal = document.getElementById('checkout-modal');
    const closeBtn = document.getElementById('close-checkout-modal-btn');
    const openBtns = document.querySelectorAll('.open-checkout-btn');
    const payTabs = document.querySelectorAll('.pay-method-tab');
    const confirmBtn = document.getElementById('confirm-payment-btn');

    openBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const pkgName = btn.getAttribute('data-pkg');
            const pkgPrice = btn.getAttribute('data-price');

            const nameEl = document.getElementById('checkout-pkg-name');
            const priceEl = document.getElementById('checkout-pkg-price');

            if (nameEl) nameEl.textContent = pkgName;
            if (priceEl) priceEl.textContent = pkgPrice;

            if (modal) modal.classList.remove('hidden');
        });
    });

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            if (modal) modal.classList.add('hidden');
        });
    }

    payTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const payType = tab.getAttribute('data-pay');
            payTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            const panels = document.querySelectorAll('.pay-panel');
            panels.forEach(p => p.classList.add('hidden'));

            const activePanel = document.getElementById(`pay-panel-${payType}`);
            if (activePanel) activePanel.classList.remove('hidden');
        });
    });

    if (confirmBtn) {
        confirmBtn.addEventListener('click', () => {
            alert('✅ Payment Received & Verified! Order dispatched to Hostinger VPS Docker Automation Queue.');
            if (modal) modal.classList.add('hidden');
        });
    }
}

/* Solution Architect Modal */
function initSolutionArchitectModal() {
    const heroBtn = document.getElementById('hero-open-architect-btn');
    const modal = document.getElementById('solution-architect-modal');
    const closeBtn = document.getElementById('close-architect-modal-btn');
    const genBtn = document.getElementById('generate-architecture-btn');
    const codeOutput = document.getElementById('architecture-output-code');

    if (heroBtn) {
        heroBtn.addEventListener('click', () => {
            if (modal) modal.classList.remove('hidden');
        });
    }

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            if (modal) modal.classList.add('hidden');
        });
    }

    if (genBtn) {
        genBtn.addEventListener('click', () => {
            const text = document.getElementById('architect-query-input').value;
            codeOutput.textContent = `// AIBOS Solution Architect Blueprint
// Target: ${text}

[Client Request] ➔ [Cloudflare DNS] ➔ [Hostinger Docker VPS]
                                     ├── [n8n Automation Engine]
                                     ├── [OpenClaw Playwright Scraper]
                                     └── [PostgreSQL + Pinecone RAG]

Cost Estimate: $599 Setup + $10/mo Hostinger VPS (Code: IINSHA20)
Status: Verified & Ready to Deploy`;
        });
    }
}

/* AI Proposal Studio Modal */
function initProposalStudioModal() {
    const modal = document.getElementById('proposal-studio-modal');
    const closeBtn = document.getElementById('close-proposal-modal-btn');
    const signBtn = document.getElementById('sign-proposal-btn');

    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            if (modal) modal.classList.remove('hidden');
        });
    }

    if (signBtn) {
        signBtn.addEventListener('click', () => {
            const name = document.getElementById('proposal-signature-input').value;
            if (!name) {
                alert('Please type your name to sign the proposal.');
                return;
            }
            alert(`✍️ Proposal Electronically Signed by ${name}! Opening Payment Gateway...`);
            if (modal) modal.classList.add('hidden');
            const checkModal = document.getElementById('checkout-modal');
            if (checkModal) checkModal.classList.remove('hidden');
        });
    }
}
